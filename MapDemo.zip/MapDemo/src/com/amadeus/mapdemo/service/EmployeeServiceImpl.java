package com.amadeus.mapdemo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amadeus.mapdemo.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	Map<String, Employee> map= new HashMap<String, Employee>();
	
	@Override
	public String insertEmployee(String id, Employee employee) {
		// TODO Auto-generated method stub
		
		if(id.equals(null))
		{
			return "notValidId";
		}
		else {
			try {
				map.put(id, employee);
				return "success";
			}
			catch(Exception e ) {
				return "fail";
			}
			
			
		}
		
	}

	@Override
	public String updateEmployee(String id, Employee employee) {
		// TODO Auto-generated method stub
		return insertEmployee(id, employee);
	}

	@Override
	public String deleteEmployee(String id) {
		// TODO Auto-generated method stub
		if(map.remove(id)!=null) {
			return "success";
		}
		else {
			return "notFound";
		}
	}

	@Override
	public Employee getEmployee(String id) {
		// TODO Auto-generated method stub
		return map.get(id);
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return new ArrayList<Employee>(map.values());
	}

	@Override
	public List<Employee> getEmployeesByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
