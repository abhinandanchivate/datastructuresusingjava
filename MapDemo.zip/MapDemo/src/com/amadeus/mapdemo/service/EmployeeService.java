package com.amadeus.mapdemo.service;

import java.util.List;

import com.amadeus.mapdemo.bean.Employee;

public interface EmployeeService {

	
	public String insertEmployee(String id, Employee employee);
	public String updateEmployee(String id, Employee employee);
	public String deleteEmployee(String id);
	public Employee getEmployee(String id);
	public List<Employee> getEmployees();
	public List<Employee> getEmployeesByName(String name);
	
}
