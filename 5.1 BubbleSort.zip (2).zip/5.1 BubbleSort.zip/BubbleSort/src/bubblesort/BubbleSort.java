package bubblesort;

/**
 *
 * 
 */
public class BubbleSort {

    public static void bubbleSort(int[] input) {
        for (int i = 0; i < input.length - 1; i++) {
            // i represents how many elements have bubbled to correct place
            for (int j = 0; j + 1 < input.length - i; j++) {
                if (input[j] > input[j + 1]) {
                    //swap
                    int temp = input[j];
                    input[j] = input[j + 1];
                    input[j + 1] = temp;
                }
            }
            for (int k : input) {
				System.out.print(k+"\t");
			}
        System.out.println("");
        }
    }



    public static void main(String[] args) {
        //initialize
        int[] input = {10, 8, 1, 88, 64, 21, 19, 4, 3, 2};
        int[] inputOpt = input;

        for (int i : inputOpt) {
			System.out.print(i+"\t");
		}
        System.out.println();
        System.out.println("sroted data");
        //sort
        bubbleSort(input);
       

        //print
		/*
		 * printArray(input); printArray(inputOpt);
		 */
    }

}
