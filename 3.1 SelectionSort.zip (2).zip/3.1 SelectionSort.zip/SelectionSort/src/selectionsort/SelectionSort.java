package selectionsort;

/**
 *
 * 
 */
public class SelectionSort {

    public static void selectionSort(int[] input) {
        for (int i = 0; i < input.length - 1; i++) {
            // i points at first number behind "wall"
            int indexOfSmallest = i;
            for (int j = i + 1; j < input.length; j++) {
                if (input[j] < input[indexOfSmallest]) {
                    indexOfSmallest = j;
                    System.out.println("every iteration");
                    for (int k : input) {
            			System.out.print(k+"\t");
            		}
                System.out.println("");
                    System.out.println("+++++++++++++++++++++++++++++++++++++++");
                }
                
                
            }
            // swap
            int temp = input[i];
            input[i] = input[indexOfSmallest];
            input[indexOfSmallest] = temp;
            
        }
        
    }

    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + ", ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        //initialize
        int[] input = {10, 8, 1, 88, 64, 21, 19, 4, 3, 2};

        printArray(input);
        System.out.println("sorting");
        //sort
        selectionSort(input);

        //print
        printArray(input);
    }

}
